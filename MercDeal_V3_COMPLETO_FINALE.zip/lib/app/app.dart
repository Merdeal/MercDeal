import 'dart:async';
import 'package:flutter/material.dart';
import 'theme.dart';
import '../features/home/home_screen.dart';
import '../features/search/search_screen.dart';
import '../features/selling/sell_screen.dart';
import '../features/messages/messages_screen.dart';
import '../features/profile/profile_screen.dart';

class MercDealApp extends StatelessWidget {
  const MercDealApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'MercDeal',
        theme: MercDealTheme.dark(),
        home: const MercDealSplash(),
      );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [HomeScreen(), SearchScreen(), SellScreen(), MessagesScreen(), ProfileScreen()];
  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(index: index, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.search_rounded), label: 'Cerca'),
            NavigationDestination(icon: Icon(Icons.add_circle_outline_rounded), selectedIcon: Icon(Icons.add_circle_rounded), label: 'Vendi'),
            NavigationDestination(icon: Icon(Icons.forum_outlined), selectedIcon: Icon(Icons.forum_rounded), label: 'Messaggi'),
            NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'Profilo'),
          ],
        ),
      );
}

class MercDealSplash extends StatefulWidget {
  const MercDealSplash({super.key});
  @override State<MercDealSplash> createState() => _MercDealSplashState();
}
class _MercDealSplashState extends State<MercDealSplash> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 1100), () {
      if (mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const MainShell()));
    });
  }
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF06120F), MercDealTheme.navy, Color(0xFF06101D)])),
          child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 96, height: 96, decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), gradient: const LinearGradient(colors: [MercDealTheme.green, MercDealTheme.blue]), boxShadow: const [BoxShadow(color: MercDealTheme.green, blurRadius: 38, spreadRadius: -15)]), child: const Icon(Icons.shopping_cart_rounded, size: 48, color: Color(0xFF03100A))),
            const SizedBox(height: 20),
            const Text('MercDeal', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, letterSpacing: -1)),
            const SizedBox(height: 5),
            const Text('Il prezzo scende. L’affare sale.', style: TextStyle(color: Colors.white60, fontWeight: FontWeight.w600)),
          ]),),
        ),
      );
}
