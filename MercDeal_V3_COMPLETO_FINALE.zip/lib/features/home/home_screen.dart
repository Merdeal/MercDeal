import 'dart:async';
import 'package:flutter/material.dart';
import '../../app/theme.dart';
import '../../core/widgets/merc_widgets.dart';
import '../../models/listing.dart';
import '../listing/listing_detail_screen.dart';
import '../notifications/notifications_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  Timer? timer;
  int discovery = 0;
  final products = const [
    Listing(id:'1',title:'Sony Alpha 7 III',category:'Fotografia',price:1179.80,startPrice:1240,minimumPrice:1090,drop:.20,followers:18,icon:Icons.camera_alt_rounded,mode:SaleMode.descendingAuction,condition:ListingCondition.excellent,verifiedSeller:true,inShowcase:true,location:'Roma'),
    Listing(id:'2',title:'PlayStation 5 Slim',category:'Gaming',price:454.80,startPrice:520,minimumPrice:420,drop:.20,followers:34,icon:Icons.sports_esports_rounded,mode:SaleMode.descendingAuction,condition:ListingCondition.excellent,verifiedSeller:true,inShowcase:false,location:'Milano'),
    Listing(id:'3',title:'Air Jordan Retro',category:'Moda',price:128.80,startPrice:160,minimumPrice:110,drop:.20,followers:27,icon:Icons.shopping_bag_rounded,mode:SaleMode.descendingAuction,condition:ListingCondition.newItem,verifiedSeller:true,inShowcase:true,location:'Torino'),
    Listing(id:'4',title:'iPad Air',category:'Elettronica',price:399.80,startPrice:450,minimumPrice:350,drop:.20,followers:41,icon:Icons.tablet_mac_rounded,mode:SaleMode.descendingAuction,condition:ListingCondition.good,verifiedSeller:true,inShowcase:false,location:'Bologna'),
  ];
  @override void initState(){super.initState(); timer=Timer.periodic(const Duration(minutes:2),(_){if(mounted)setState(()=>discovery=(discovery+1)%products.length);});}
  @override void dispose(){timer?.cancel();super.dispose();}
  void open(Listing x)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ListingDetailScreen(listing:x)));
  @override Widget build(BuildContext context){
    final featured=products[discovery];
    return SafeArea(child:CustomScrollView(physics:const BouncingScrollPhysics(),slivers:[
      SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(18,16,18,0),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[Container(width:45,height:45,decoration:BoxDecoration(borderRadius:BorderRadius.circular(15),gradient:const LinearGradient(colors:[MercDealTheme.green,MercDealTheme.blue]),boxShadow:const [BoxShadow(color:Color(0x4439A7FF),blurRadius:20)]),child:const Icon(Icons.shopping_cart_rounded,color:Color(0xFF03100A))),const SizedBox(width:11),const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('MercDeal',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)),Text('SCONTI CHE VIVONO',style:TextStyle(fontSize:9,color:MercDealTheme.green,fontWeight:FontWeight.w900,letterSpacing:1.5))]),const Spacer(),IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const NotificationsScreen())),icon:const Icon(Icons.notifications_none_rounded))]),
        const SizedBox(height:15),
        Container(height:54,padding:const EdgeInsets.symmetric(horizontal:16),decoration:BoxDecoration(color:MercDealTheme.card,borderRadius:BorderRadius.circular(19),border:Border.all(color:Colors.white.withValues(alpha:.06))),child:const Row(children:[Icon(Icons.search_rounded,color:Colors.white54),SizedBox(width:10),Expanded(child:Text('Cerca il tuo prossimo affare…',style:TextStyle(color:Colors.white38))),Icon(Icons.mic_none_rounded,color:MercDealTheme.green)])),
        const SizedBox(height:16),
        SizedBox(height:38,child:ListView.separated(scrollDirection:Axis.horizontal,itemCount:7,separatorBuilder:(_,__)=>const SizedBox(width:8),itemBuilder:(c,i){const labels=['Tutto','Elettronica','Gaming','Moda','Casa','Fotografia','Sport'];return Container(padding:const EdgeInsets.symmetric(horizontal:15),alignment:Alignment.center,decoration:BoxDecoration(color:i==0?MercDealTheme.green:MercDealTheme.card,borderRadius:BorderRadius.circular(14)),child:Text(labels[i],style:TextStyle(color:i==0?const Color(0xFF04120B):Colors.white70,fontWeight:FontWeight.w800)));})),
        const SizedBox(height:17),
        GestureDetector(onTap:()=>open(featured),child:Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(borderRadius:BorderRadius.circular(28),gradient:const LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,colors:[Color(0xFF123C35),Color(0xFF0B1A28),Color(0xFF102947)]),border:Border.all(color:MercDealTheme.green.withValues(alpha:.22)),boxShadow:const [BoxShadow(color:Color(0x2229F59A),blurRadius:35)]),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:6),decoration:BoxDecoration(color:MercDealTheme.green.withValues(alpha:.14),borderRadius:BorderRadius.circular(10)),child:const Text('📉 ASTA AL RIBASSO',style:TextStyle(color:MercDealTheme.green,fontSize:11,fontWeight:FontWeight.w900,letterSpacing:1)),),const Spacer(),const Icon(Icons.bolt_rounded,color:MercDealTheme.green)]),
          const SizedBox(height:12),const Text('Il prezzo scende.',style:TextStyle(fontSize:29,fontWeight:FontWeight.w900)),const Text('L’affare sale.',style:TextStyle(fontSize:29,fontWeight:FontWeight.w900,color:MercDealTheme.green)),
          const SizedBox(height:10),const Text('Ogni giorno −€0,20. Aspetti o lo prendi?',style:TextStyle(color:Colors.white60)),const SizedBox(height:17),
          Row(children:[Expanded(child:Text(featured.title,style:const TextStyle(fontWeight:FontWeight.w800))),Text('€${featured.price.toStringAsFixed(2).replaceAll('.',',')}',style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900,color:MercDealTheme.green))])
        ]))),
      ]))),
      SliverToBoxAdapter(child:_section('✨ Scopri ora','Cambia ogni 2 minuti',products,open,discovery)),
      SliverToBoxAdapter(child:_section('🔥 Sta scendendo ora','Aste attive',products,open,1)),
      SliverToBoxAdapter(child:_target(products[2],open)),
      SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(18,22,18,12),child:const Text('Esplora per categoria',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)))),
      SliverToBoxAdapter(child:SizedBox(height:96,child:ListView.separated(padding:const EdgeInsets.symmetric(horizontal:18),scrollDirection:Axis.horizontal,itemCount:6,separatorBuilder:(_,__)=>const SizedBox(width:10),itemBuilder:(c,i){const data=[['Elettronica',Icons.devices_rounded],['Gaming',Icons.sports_esports_rounded],['Moda',Icons.checkroom_rounded],['Casa',Icons.chair_rounded],['Foto',Icons.camera_alt_rounded],['Sport',Icons.directions_run_rounded]];return Container(width:104,padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:MercDealTheme.card,borderRadius:BorderRadius.circular(20),border:Border.all(color:Colors.white.withValues(alpha:.05))),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(data[i][1] as IconData,color:MercDealTheme.green),const SizedBox(height:6),Text(data[i][0] as String,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w800))]));}))),
      SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(18,22,18,30),child:Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:MercDealTheme.card,borderRadius:BorderRadius.circular(22)),child:Row(children:[Container(width:45,height:45,decoration:BoxDecoration(color:MercDealTheme.green.withValues(alpha:.12),borderRadius:BorderRadius.circular(14)),child:const Icon(Icons.auto_awesome_rounded,color:MercDealTheme.green)),const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Non cercare soltanto.',style:TextStyle(fontWeight:FontWeight.w900)),Text('Scopri il prossimo affare.',style:TextStyle(color:Colors.white54,fontSize:12))])),const Icon(Icons.arrow_forward_ios_rounded,size:15,color:Colors.white30)]))))
    ])));
  }
  Widget _section(String title,String action,List<Listing> data,void Function(Listing) open,int shift)=>Padding(padding:const EdgeInsets.only(top:22),child:Column(children:[Padding(padding:const EdgeInsets.symmetric(horizontal:18),child:SectionHeader(title:title,action:action)),const SizedBox(height:10),SizedBox(height:235,child:ListView.separated(padding:const EdgeInsets.symmetric(horizontal:18),scrollDirection:Axis.horizontal,itemCount:data.length,separatorBuilder:(_,__)=>const SizedBox(width:12),itemBuilder:(c,i){final x=data[(i+shift)%data.length];return DealCard(title:x.title,price:'€${x.price.toStringAsFixed(2).replaceAll('.',',')}',subtitle:'−€0,20 · ${x.followers} seguono',icon:x.icon,featured:x.inShowcase,onTap:()=>open(x),following:i==0);}))]));
  Widget _target(Listing x,void Function(Listing) open)=>Padding(padding:const EdgeInsets.fromLTRB(18,22,18,0),child:GestureDetector(onTap:()=>open(x),child:Container(padding:const EdgeInsets.all(17),decoration:BoxDecoration(color:MercDealTheme.card,borderRadius:BorderRadius.circular(22),border:Border.all(color:MercDealTheme.blue.withValues(alpha:.16))),child:Row(children:[Container(width:50,height:50,decoration:BoxDecoration(color:MercDealTheme.blue.withValues(alpha:.12),borderRadius:BorderRadius.circular(15)),child:const Icon(Icons.track_changes_rounded,color:MercDealTheme.blue)),const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('⚡ Quasi al tuo prezzo',style:TextStyle(fontWeight:FontWeight.w900)),Text('Air Jordan · target €120 · ora €128,80',style:TextStyle(color:Colors.white54,fontSize:12))])),const Icon(Icons.chevron_right_rounded,color:Colors.white38)])));
}
