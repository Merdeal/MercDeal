# MercDeal V3 — Final Project

MercDeal is a modern Italian marketplace centered on the downward-price auction.

## V3 experience
- Dark glossy interface with neon green/blue visual system
- Branded splash and MercDeal identity
- Home with dynamic discovery, falling-price sections, target-price section and categories
- Search with categories, filters and sorting
- Sell flow: Buy Now / Downward Auction / Free Offer
- Downward Auction: 7/15/30 days, automatic -€0.20/day, hidden seller minimum
- Listing detail with follow/favorite and purchase/offer actions
- Checkout showing shipping before confirmation, including destination CAP
- Hand pickup flow with seller-selected meeting point and temporary location sharing concept
- Orders and shipping/tracking flow
- Chat and messages
- Notifications
- Profile, reputation, reviews and verified-seller presentation
- Deal+ at €4.99/month or €39.99/year concept
- Vetrina Premium for 7 days
- MercDeal Authenticity and Security / Report flows
- Packing video and printable Security Seal concepts
- Supabase foundations and server-authoritative business rules

## Production integrations still requiring provider accounts
Payment marketplace/KYC, carrier rates and labels, maps/geolocation, push notifications, webhooks and store subscriptions require real provider configuration and secrets. The UI does not pretend these services are already live.

## Build note
The environment used to prepare this package does not contain the Flutter SDK, so a successful `flutter test`/`flutter build` cannot be claimed here. Codemagic is the final build verification environment.
